import asyncio
import logging
import os

from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("BOT_TOKEN", "").strip()

PLANS = {
    "month": ("1 месяц", "199 ₽"),
    "quarter": ("3 месяца", "499 ₽"),
    "halfyear": ("6 месяцев", "899 ₽"),
    "year": ("12 месяцев", "1499 ₽"),
}

def main_keyboard():
    kb = InlineKeyboardBuilder()
    kb.button(text="🛒 Купить VPN", callback_data="buy")
    kb.button(text="👤 Моя подписка", callback_data="account")
    kb.button(text="📖 Инструкция подключения", callback_data="guide")
    kb.button(text="🆘 Поддержка", callback_data="support")
    kb.adjust(1)
    return kb.as_markup()

def plans_keyboard():
    kb = InlineKeyboardBuilder()
    for key, (label, price) in PLANS.items():
        kb.button(text=f"{label} — {price}", callback_data=f"plan:{key}")
    kb.button(text="⬅️ Главное меню", callback_data="home")
    kb.adjust(1)
    return kb.as_markup()

async def start(message: Message):
    await message.answer(
        "🛡 <b>SHADOW VPN</b>\n\n"
        "Добро пожаловать! Выберите действие ниже.\n\n"
        "🇩🇪 Первый узел: Германия\n"
        "⚡ Протокол: WireGuard",
        reply_markup=main_keyboard(),
        parse_mode="HTML",
    )

async def callbacks(callback: CallbackQuery):
    data = callback.data or ""

    if data == "home":
        await callback.message.edit_text(
            "🛡 <b>SHADOW VPN</b>\n\nВыберите действие:",
            reply_markup=main_keyboard(),
            parse_mode="HTML",
        )
    elif data == "buy":
        await callback.message.edit_text(
            "💎 <b>Выберите тариф Shadow VPN</b>\n\n"
            "Цены пока демонстрационные. Приём оплаты ещё не подключён.",
            reply_markup=plans_keyboard(),
            parse_mode="HTML",
        )
    elif data.startswith("plan:"):
        key = data.split(":", 1)[1]
        label, price = PLANS.get(key, ("Неизвестный тариф", "—"))
        await callback.message.edit_text(
            f"Вы выбрали: <b>{label}</b> — <b>{price}</b>.\n\n"
            "Оплата и автоматическая выдача VPN-доступа пока не подключены. "
            "Не переводите деньги по этому демонстрационному меню.",
            reply_markup=plans_keyboard(),
            parse_mode="HTML",
        )
    elif data == "account":
        await callback.message.edit_text(
            "👤 <b>Моя подписка</b>\n\n"
            "Активная подписка не найдена.\n"
            "После подключения базы данных здесь появятся срок действия и статус.",
            reply_markup=main_keyboard(),
            parse_mode="HTML",
        )
    elif data == "guide":
        await callback.message.edit_text(
            "📖 <b>Подключение</b>\n\n"
            "После настройки сервера здесь появятся инструкции для iPhone, "
            "Android, Windows и macOS.",
            reply_markup=main_keyboard(),
            parse_mode="HTML",
        )
    elif data == "support":
        await callback.message.edit_text(
            "🆘 <b>Поддержка Shadow VPN</b>\n\n"
            "Контакт поддержки ещё не настроен. Добавьте свой username "
            "администратора перед запуском продаж.",
            reply_markup=main_keyboard(),
            parse_mode="HTML",
        )

    await callback.answer()

async def main():
    if not TOKEN or TOKEN == "PASTE_YOUR_BOTFATHER_TOKEN_HERE":
        raise RuntimeError(
            "Не задан BOT_TOKEN. Скопируйте .env.example в .env "
            "и вставьте токен от @BotFather."
        )

    logging.basicConfig(level=logging.INFO)
    bot = Bot(TOKEN)
    dp = Dispatcher()
    dp.message.register(start, CommandStart())
    dp.callback_query.register(callbacks, F.data)
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
